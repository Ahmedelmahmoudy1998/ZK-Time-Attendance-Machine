============
Contributing
============

Contributions are welcome, and they are greatly appreciated! Every
little bit helps, and credit will always be given.

You can contribute in many ways:

Types of Contributions
----------------------

Report Bugs
~~~~~~~~~~~

Report bugs at https://github.com/MeirKriheli/python-bidi/issues.

If you are reporting a bug, please include:

* Your operating system name and version.
* Any details about your local setup that might be helpful in troubleshooting.
* Detailed steps to reproduce the bug.

Fix Bugs
~~~~~~~~

Look through the GitHub issues for bugs. Anything tagged with "bug"
is open to whoever wants to implement it.

Implement Features
~~~~~~~~~~~~~~~~~~

Look through the GitHub issues for features. Anything tagged with "feature"
is open to whoever wants to implement it.

Write Documentation
~~~~~~~~~~~~~~~~~~~

Python BiDi could always use more documentation, whether as part of the
official Python BiDi docs, in docstrings, or even on the web in blog posts,
articles, and such.

Submit Feedback
~~~~~~~~~~~~~~~

The best way to send feedback is to file an issue at https://github.com/MeirKriheli/python-bidi/issues.

If you are proposing a feature:

* Explain in detail how it would work.
* Keep the scope as narrow as possible, to make it easier to implement.
* Remember that this is a volunteer-driven project, and that contributions
  are welcome :)

Get Started!
------------

Ready to contribute? Here's how to set up `python-bidi` for local development.

1. Fork the ``python-bidi`` repo on GitHub.
2. Clone your fork locally::

    $ git clone git@github.com:your_name_here/python-bidi.git

3. Install prerequisites:

   * `Rust <https://www.rust-lang.org/tools/install>`_ (the extension is built with PyO3 / maturin).
   * `uv <https://docs.astral.sh/uv/installation/>`_ (Python envs, dependency lockfile, and nox’s ``venv_backend="uv"``).

4. In the repo, sync the dev environment and run tests::

    $ cd python-bidi/
    $ uv sync --extra dev
    $ uv run pytest

   This uses ``uv.lock`` when present for reproducible installs. To match CI-style checks via nox (also using uv under the hood)::

    $ uv run nox

   Alternatively, install nox globally (``uv tool install nox``, ``pipx install nox``, etc.) and run ``nox`` from the repo root.

5. Create a branch for local development::

    $ git switch -c name-of-your-bugfix-or-feature

   Now you can make your changes locally.

6. When you're ready, ensure tests still pass (see step 4).

7. Commit your changes and push your branch to GitHub::

    $ git add .
    $ git commit -m "Your detailed description of your changes."
    $ git push origin name-of-your-bugfix-or-feature

8. Submit a pull request through the GitHub website.

Pull Request Guidelines
-----------------------

Before you submit a pull request, check that it meets these guidelines:

1. The pull request should include tests.
2. If the pull request adds functionality, the docs should be updated. Put
   your new functionality into a function with a docstring, and add the
   feature to the list in README.rst.
